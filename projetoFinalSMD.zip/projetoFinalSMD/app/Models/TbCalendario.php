<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TbCalendario extends Model
{
    use HasFactory;

    protected $fillable = [
        'hora',
        'dia',
        'nome_utente',
        'localizacao',
        'id_equipa',
        'id_utente'
    ];
}
