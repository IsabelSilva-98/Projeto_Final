<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TbDespesa extends Model
{
    use HasFactory;

    protected $fillable = [
        'data',
        'combustivel',
        'mapa_km',
        'portagens',
        'id_funcionario',
        'equipa'
    ];
}
