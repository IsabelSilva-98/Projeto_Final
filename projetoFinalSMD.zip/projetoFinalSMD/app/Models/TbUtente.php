<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TbUtente extends Model
{
    use HasFactory;

    protected $fillable = [
        'no_utente',
        'nome',
        'data_nascimento',
        'sexo',
        'email',
        'contacto'
    ];
}