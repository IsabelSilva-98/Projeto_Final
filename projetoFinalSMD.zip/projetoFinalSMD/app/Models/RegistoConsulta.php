<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RegistoConsulta extends Model
{
    use HasFactory;


}



// $table->integer('id_consulta')->index('id_consulta');
//             $table->integer('id_equipa')->index('id_equipa');
//             $table->integer('id_utente')->index('id_utente');
//             $table->date('data_consulta');
//             $table->integer('id_triagem')->index('id_utente');