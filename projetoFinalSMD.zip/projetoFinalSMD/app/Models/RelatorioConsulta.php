<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RelatorioConsulta extends Model
{
    use HasFactory;

    protected $fillable = [
        'data',
        'nome_utente',
        'diagnostico',
        'tensao_diastolica',
        'tensao_sistolica',
        'id_consulta'
    ];
}
