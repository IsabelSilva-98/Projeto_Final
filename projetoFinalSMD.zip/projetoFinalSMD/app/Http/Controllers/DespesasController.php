<?php

namespace App\Http\Controllers;

use App\Models\TbDespesa;
use Illuminate\Http\Request;

class DespesasController extends Controller
{
    //
    public function index(){
        $despesas = TbDespesa::all();
        return view('despesas.despesasindex', ['despesas'=>$despesas]);
    }

    public function create()
    {
        return view('despesas.despesascreate');
    }

    public function store(Request $request)
   {
        //dd($request);
        TbDespesa::create($request->all());
        return redirect()->route('despesas.despesasindex');
        
   }

   public function show(int $id_despesa)
    {
        $despesas = TbDespesa::where('id_despesa', $id_despesa)->first();
        return view('despesas.despesasshow', ['despesas'=>$despesas]);
    }


   public function edit($id_despesa)
   {
        $despesas = TbDespesa::where('id_despesa', $id_despesa)->first();
        if(!empty($despesas))
        {
             return view('despesas.despesasedit', ['despesas'=>$despesas]);
        }
        else
        {
             return redirect()->route('despesas.despesasindex');
        }
   }

   public function update(Request $request, $id_despesa)
     {
          //dd($request);
          $data = [
               'data' => $request->data,
               'combustivel' => $request->combustivel,
               'mapa_km' => $request->mapa_km,
               'portagens' => $request->portagens,
               'id_funcionario' => $request->id_funcionario,
               'equipa' => $request->equipa
          ];
          TbDespesa::where('id_despesa', $id_despesa)->update($data);
          return redirect()->route('despesas.despesasindex');
     }

     public function destroy($id_despesa)
     {
        TbDespesa::where('id_despesa', $id_despesa)->delete();
        return redirect()->route('despesas.despesasindex');
     }
}
