<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TbEquipamento;

class EquipamentoController extends Controller
{
    //
    public function index1(){
        $equipamento=TbEquipamento::all();
        return view('equipamento.equipamentoindex1', ['equipamento'=>$equipamento]);
    }

    public function index2(){
     $equipamento=TbEquipamento::all();
     return view('equipamento.equipamentoindex2', ['equipamento'=>$equipamento]);
 }

 public function index3(){
     $equipamento=TbEquipamento::all();
     return view('equipamento.equipamentoindex3', ['equipamento'=>$equipamento]);
 }

 public function index4(){
     $equipamento=TbEquipamento::all();
     return view('equipamento.equipamentoindex4', ['equipamento'=>$equipamento]);
 }

 public function index5(){
     $equipamento=TbEquipamento::all();
     return view('equipamento.equipamentoindex5', ['equipamento'=>$equipamento]);
 }

 public function index6(){
     $equipamento=TbEquipamento::all();
     return view('equipamento.equipamentoindex6', ['equipamento'=>$equipamento]);
 }


    public function create()
    {
        return view('equipamento.equipamentocreate');
    }

    public function store(Request $request)
   {
        //dd($request);
        TbEquipamento::create($request->all());
        return redirect()->route('equipamento.equipamentoindex');
        
   }


    
    public function edit($id_equipamento)
     {
          $equipamento = TbEquipamento::where('id_equipamento', $id_equipamento)->first();
          if(!empty($equipamento))
          {
               return view('equipamento.equipamentoedit', ['equipamento'=>$equipamento]);
          }
          else
          {
               return redirect()->route('equipamento.equipamentoindex');
          }
     }

     public function update(Request $request, $id_equipamento)
     {
          //dd($request);
          $data = [
               'nome' => $request->nome,
               'quantidade' => $request->quantidade,
          ];
          TbEquipamento::where('id_equipamento', $id_equipamento)->update($data);
          return redirect()->route('equipamento.equipamentoindex');
     }


     public function destroy($id_equipamento)
     {
        TbEquipamento::where('id_equipamento', $id_equipamento)->delete();
          return redirect()->route('equipamento.equipamentoindex');
     }
}
