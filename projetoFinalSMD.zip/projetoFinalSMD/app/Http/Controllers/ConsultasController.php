<?php

namespace App\Http\Controllers;

use App\Models\TbConsulta;
use Illuminate\Http\Request;

class ConsultasController extends Controller
{
    public function index()
    {
        //dd('ola');

        $consultas=TbConsulta::all();
        //dd($consultas);
        return view('menu.consultasindex', ['consultas'=>$consultas]);

        // $nome = 'Isabel';
        // return view ('menu_doutor.consultas', ['nome'=>$nome]);
   }

   public function create()
   {
        return view('menu.consultascreate');
   }

   public function store(Request $request)
   {
        //dd($request);
        TbConsulta::create($request->all());
        return redirect()->route('menu.consultasindex');
   }

   public function show(int $id_consulta)
   {
       $consultas = TbConsulta::where('id_consulta', $id_consulta)->first();
       return view('menu.consultasshow', ['consultas'=>$consultas]);
   }

   public function edit($id_consulta)
     {
          $consultas = TbConsulta::where('id_consulta', $id_consulta)->first();
          if(!empty($consultas))
          {
               return view('menu.consultasedit', ['consultas'=>$consultas]);
          }
          else
          {
               return redirect()->route('menu.consultasindex');
          }
     }

     public function update(Request $request, $id_consulta)
     {
          //dd($request);
          $data = [
               'nome_utente' => $request->nome_utente,
               'data' => $request->data,
               'diagnostico' => $request->diagnostico,
               'antecedentes' => $request->antecedentes,
               'medicacao' => $request->medicacao,
               'id_triagem' => $request->id_triagem,
               'id_utente' => $request->id_utente,
               'id_equipa' => $request->id_equipa,
               
          ];
          TbConsulta::where('id_consulta', $id_consulta)->update($data);
          return redirect()->route('menu.consultasindex');
     }

     public function destroy($id_consulta)
     {
          TbConsulta::where('id_consulta', $id_consulta)->delete();
          return redirect()->route('menu.consultasindex');
     }
    
}
