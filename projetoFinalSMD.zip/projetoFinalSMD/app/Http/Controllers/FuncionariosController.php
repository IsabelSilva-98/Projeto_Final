<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class FuncionariosController extends Controller
{
    //

    public function index(){
        $funcionarios = User::all();
        return view('menu.funcionariosindex', ['funcionarios'=>$funcionarios]);
    }

    public function create()
    {
        return view('menu.funcionarioscreate');
    }

    public function store(Request $request)
   {
        //dd($request);
        User::create($request->all());
        return redirect()->route('menu.funcionariosindex');
        
   }

   public function show(int $id_user)
   {
       $funcionarios = User::where('id_user', $id_user)->first();
       return view('menu.funcionariosshow', ['funcionarios'=>$funcionarios]);
   }

   public function edit($id_user)
     {
          $funcionarios = User::where('id_user', $id_user)->first();
          if(!empty($funcionarios))
          {
               return view('menu.funcionariosedit', ['funcionarios'=>$funcionarios]);
          }
          else
          {
               return redirect()->route('menu.funcionariosindex');
          }
     }


     public function update(Request $request, $id_user)
     {
          //dd($request);
          $data = [
               'nome' => $request->nome,
               'data_nascimento' => $request->data_nascimento,
               'sexo' => $request->sexo,
               'email' => $request->email,
               'contacto' => $request->contacto,
               'id_equipa' => $request->id_equipa,
               'funcao' => $request->funcao,
               'password' => $request->password,
               
          ];
          User::where('id_user', $id_user)->update($data);
          return redirect()->route('menu.funcionariosindex');
     }

     public function destroy($id_user)
     {
          User::where('id_user', $id_user)->delete();
          return redirect()->route('menu.funcionariosindex');
     }







     /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
     'password',
     'remember_token',
     'two_factor_recovery_codes',
     'two_factor_secret',
 ];

 /**
  * The attributes that should be cast.
  *
  * @var array<string, string>
  */
 protected $casts = [
     'email_verified_at' => 'datetime',
 ];

 /**
  * The accessors to append to the model's array form.
  *
  * @var array<int, string>
  */
 protected $appends = [
     'profile_photo_url',
 ];
}
