<?php

namespace App\Http\Controllers;

use App\Models\TbTriagem;
use Illuminate\Http\Request;

class TriagemController extends Controller
{
    //
    public function index(){
        $triagem=TbTriagem::all();
        return view('menu.triagemindex', ['triagem'=>$triagem]);
    }

    public function create()
    {
        return view('menu.triagemcreate');
    }

    public function store(Request $request)
   {
        //dd($request);
        TbTriagem::create($request->all());
        return redirect()->route('menu.triagemindex');
        
   }

   public function show(int $id_utente)
    {
        $triagem = TbTriagem::where('id_utente', $id_utente)->first();
        return view('menu.triagemshow', ['triagem'=>$triagem]);
    }

    public function edit($id_triagem)
     {
          $triagem = TbTriagem::where('id_triagem', $id_triagem)->first();
          if(!empty($triagem))
          {
               return view('menu.triagemedit', ['triagem'=>$triagem]);
          }
          else
          {
               return redirect()->route('menu.triagemindex');
          }
     }

     public function update(Request $request, $id_triagem)
     {
          //dd($request);
          $data = [
               'nome_utente' => $request->nome_utente,
               'id_utente' => $request->id_utente,
               'peso' => $request->peso,
               'altura' => $request->altura,
               'colestrol' => $request->colestrol,
               'glicose' => $request->glicose,
               'tensao_diastolica' => $request->tensao_diastolica,
               'tensao_sistolica' => $request->tensao_sistolica,
               
          ];
          TbTriagem::where('id_triagem', $id_triagem)->update($data);
          return redirect()->route('menu.triagemindex');
     }

     public function destroy($id_triagem)
     {
          TbTriagem::where('id_triagem', $id_triagem)->delete();
          return redirect()->route('menu.triagemindex');
     }
}
