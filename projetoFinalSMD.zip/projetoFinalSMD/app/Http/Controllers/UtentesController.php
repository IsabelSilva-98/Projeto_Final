<?php

namespace App\Http\Controllers;

use App\Models\TbUtente;
use Illuminate\Http\Request;

class UtentesController extends Controller
{
    //
    public function index()
    {

        $utentes=TbUtente::all();
        return view('menu.utentesindex', ['utentes'=>$utentes]);

    }
    
    public function create()
    {
         return view('menu.utentescreate');
    }

     public function store(Request $request)
     {
        //dd($request);
        TbUtente::create($request->all());
        return redirect()->route('menu.utentesindex');
        
     }

     public function show(int $id_utente)
     {
          $utentes = TbUtente::where('id_utente', $id_utente)->first();
          return view('menu.utentesshow', ['utentes'=>$utentes]);
     }

     public function edit($id_utente)
     {
          $utentes = TbUtente::where('id_utente', $id_utente)->first();
          if(!empty($utentes))
          {
               return view('menu.utentesedit', ['utentes'=>$utentes]);
          }
          else
          {
               return redirect()->route('menu.utentesindex');
          }

          //dd($utente);
     }


     public function update(Request $request, $id_utente)
     {
          //dd($request);
          $data = [
               'no_utente' => $request->no_utente,
               'nome' => $request->nome,
               'data_nascimento' => $request->data_nascimento,
               'sexo' => $request->sexo,
               'email' => $request->email,
               'contacto' => $request->contacto,
               
          ];
          TbUtente::where('id_utente', $id_utente)->update($data);
          return redirect()->route('menu.utentesindex');
     }

     public function destroy($id_utente)
     {
          //dd($id_utente);
          TbUtente::where('id_utente', $id_utente)->delete();
          return redirect()->route('menu.utentesindex');
     }

    
}
