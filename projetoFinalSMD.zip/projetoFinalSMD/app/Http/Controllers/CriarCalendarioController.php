<?php

namespace App\Http\Controllers;

use App\Models\TbCalendario;
use Illuminate\Http\Request;

class CriarCalendarioController extends Controller
{
    //


    public function index()
    {
        $calendario=TbCalendario::all();
        return view ('calendario.calendarioindex', ['calendario'=>$calendario]);
    }

    public function create()
   {
        return view('calendario.calendariocreate');
   }

   public function store(Request $request)
   {
        //dd($request);
        TbCalendario::create($request->all());
        return redirect()->route('calendario.calendarioindex');
   }



}
