<?php

namespace App\Http\Controllers;

use App\Models\RelatorioConsulta;
use Illuminate\Http\Request;

class RelatorioConsultasController extends Controller
{
    //

    public function index(){
        $relatorioconsulta=RelatorioConsulta::all();
        return view('menu_relatorios.relatorioconsultasindex', ['relatorioconsulta'=>$relatorioconsulta]);
    }

    public function create()
    {
        return view('menu_relatorios.relatorioconsultascreate');
    }

    public function store(Request $request)
    {
         //dd($request);
         RelatorioConsulta::create($request->all());
         return redirect()->route('menu_relatorios.relatorioconsultasindex');
         
    }

    public function show(int $id_relatorio_consulta)
    {
        $relatorioconsulta = RelatorioConsulta::where('id_relatorio_consulta', $id_relatorio_consulta)->first();
        return view('menu_relatorios.relatorioconsultasshow', ['relatorioconsulta'=>$relatorioconsulta]);
    }

    public function edit($id_relatorio_consulta)
     {
          $relatorioconsulta = RelatorioConsulta::where('id_relatorio_consulta', $id_relatorio_consulta)->first();
          if(!empty($relatorioconsulta))
          {
               return view('menu_relatorios.relatorioconsultasedit', ['relatorioconsulta'=>$relatorioconsulta]);
          }
          else
          {
               return redirect()->route('menu_relatorios.relatorioconsultasindex');
          }
     }

     public function update(Request $request, $id_relatorio_consulta)
     {
          //dd($request);
          $data = [
               'data' => $request->data,
               'nome_utente' => $request->nome_utente,
               'diagnostico' => $request->diagnostico,
               'tensao_diastolica' => $request->tensao_diastolica,
               'tensao_sistolica' => $request->tensao_sistolica,
               'id_consulta' => $request->id_consulta,
               
            ];
            RelatorioConsulta::where('id_relatorio_consulta', $id_relatorio_consulta)->update($data);
            return redirect()->route('menu_relatorios.relatorioconsultasindex');
     }
}
