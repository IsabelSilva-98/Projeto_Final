<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    //
    public function index(){
        $login = Auth::user->all();
        return view('auth.login', ['login'=>$login]);
    }

    
}
