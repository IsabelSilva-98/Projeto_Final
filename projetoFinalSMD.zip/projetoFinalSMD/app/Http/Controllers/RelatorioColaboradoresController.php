<?php

namespace App\Http\Controllers;

use App\Models\RelatorioColaboradore;
use Illuminate\Http\Request;

class RelatorioColaboradoresController extends Controller
{
    //
    public function index(){
        $relatoriocolab=RelatorioColaboradore::all();
        return view('menu_relatorios.relatoriocolaboradoresindex', ['relatoriocolab'=>$relatoriocolab]);
    }

    public function create()
    {
        return view('menu_relatorios.relatoriocolaboradorescreate');
    }

    public function store(Request $request)
    {
         //dd($request);
         RelatorioColaboradore::create($request->all());
         return redirect()->route('menu_relatorios.relatoriocolaboradoresindex');
         
    }

    public function show(int $id_relatorio_colab)
    {
        $relatoriocolab = RelatorioColaboradore::where('id_relatorio_colab', $id_relatorio_colab)->first();
        return view('menu_relatorios.relatoriocolaboradoresshow', ['relatoriocolab'=>$relatoriocolab]);
    }

    public function edit($id_relatorio_colab)
     {
          $relatoriocolab = RelatorioColaboradore::where('id_relatorio_colab', $id_relatorio_colab)->first();
          if(!empty($relatoriocolab))
          {
               return view('menu_relatorios.relatoriocolaboradoresedit', ['relatoriocolab'=>$relatoriocolab]);
          }
          else
          {
               return redirect()->route('menu_relatorios.relatoriocolaboradoresindex');
          }
     }

     public function update(Request $request, $id_relatorio_colab)
     {
          //dd($request);
          $data = [
               'data' => $request->data,
               'nome_colaborador' => $request->nome_colaborador,
               'salario' => $request->salario,
               'funcao' => $request->funcao,
               'equipa' => $request->equipa,
               'id_funcionario' => $request->id_funcionario,
               
            ];
          RelatorioColaboradore::where('id_relatorio_colab', $id_relatorio_colab)->update($data);
          return redirect()->route('menu_relatorios.relatoriocolaboradoresindex');
     }
}
