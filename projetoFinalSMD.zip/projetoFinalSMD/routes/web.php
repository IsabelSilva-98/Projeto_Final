<?php

use App\Http\Controllers\ConsultasController;
use App\Http\Controllers\UtentesController;
use App\Http\Controllers\TriagemController;
use App\Http\Controllers\CriarCalendarioController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RelatorioColaboradoresController;
use App\Http\Controllers\RelatorioConsultasController;
use App\Http\Controllers\RelatorioEstatisticasController;
use App\Http\Controllers\EquipamentoController;
use App\Http\Controllers\DespesasController;

use App\Http\Controllers\FuncionariosController;

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::middleware(['auth:sanctum', 'verified'])->get('dashboard', function(){
    return view('dashboard');
})->name('dashboard');



Route::fallback(function(){return "Erro ao localizar a rota!";});

Route::get('/login', [UserController::class, 'index'])->name('auth.login');


Route::view('/menu', 'menu.menu')->name('menu.menu');


Route::prefix('/consultas')->group(function(){

    Route::get('/', [ConsultasController::class, 'index'])->name('menu.consultasindex');
    Route::get('/create', [ConsultasController::class, 'create'])->name('menu.consultascreate');
    Route::post('/', [ConsultasController::class, 'store'])->name('consulta.store');
    Route::get('/{id_consulta}/show', [ConsultasController::class, 'show'])->where('id_consulta', '[0-9]+')->name('menu.consultasshow');
    Route::get('/{id_consulta}/edit', [ConsultasController::class, 'edit'])->where('id_consulta', '[0-9]+')->name('menu.consultasedit');
    Route::put('/{id_consulta}', [ConsultasController::class, 'update'])->where('id_consulta', '[0-9]+')->name('consultas.update');
    Route::delete('/{id_consulta}', [ConsultasController::class, 'destroy'])->where('id_consulta', '[0-9]+')->name('consultas.destroy');

});




Route::prefix('/calendario')->group(function(){
    Route::get('/', [CriarCalendarioController::class, 'index'])->name('calendario.calendarioindex');
    Route::get('/create', [CriarCalendarioController::class, 'create'])->name('calendario.calendariocreate');
    Route::post('/', [CriarCalendarioController::class, 'store'])->name('calendario.store');
});





Route::prefix('/utentes')->group(function(){
    Route::get('/', [UtentesController::class, 'index'])->name('menu.utentesindex');
    Route::get('/create', [UtentesController::class, 'create'])->name('menu.utentescreate');
    Route::post('/', [UtentesController::class, 'store'])->name('utente.store');
    Route::get('/{id_utente}/show', [UtentesController::class, 'show'])->where('id_utente', '[0-9]+')->name('menu.utentesshow');
    Route::get('/{id_utente}/edit', [UtentesController::class, 'edit'])->where('id_utente', '[0-9]+')->name('menu.utentesedit');
    Route::put('/{id_utente}', [UtentesController::class, 'update'])->where('id_utente', '[0-9]+')->name('utente.update');
    Route::delete('/{id_utente}', [UtentesController::class, 'destroy'])->where('id_utente', '[0-9]+')->name('utente.destroy');
});

Route::prefix('/funcionarios')->group(function(){
    Route::get('/', [FuncionariosController::class, 'index'])->name('menu.funcionariosindex');
    Route::get('/create', [FuncionariosController::class, 'create'])->name('menu.funcionarioscreate');
    Route::post('/', [FuncionariosController::class, 'store'])->name('funcionarios.store');
    Route::get('/{id_funcionario}/show', [FuncionariosController::class, 'show'])->where('id_funcionario', '[0-9]+')->name('menu.funcionariosshow');
    Route::get('/{id_funcionario}/edit', [FuncionariosController::class, 'edit'])->where('id_funcionario', '[0-9]+')->name('menu.funcionariosedit');
    Route::put('/{id_funcionario}', [FuncionariosController::class, 'update'])->where('id_funcionario', '[0-9]+')->name('funcionarios.update');
    Route::delete('/{id_funcionario}', [FuncionariosController::class, 'destroy'])->where('id_funcionario', '[0-9]+')->name('funcionarios.destroy');
});

Route::prefix('/equipamento')->group(function(){
    Route::get('/equipa1', [EquipamentoController::class, 'index1'])->name('equipamento.equipamentoindex1');
    Route::get('/equipa2', [EquipamentoController::class, 'index2'])->name('equipamento.equipamentoindex2');
    Route::get('/equipa3', [EquipamentoController::class, 'index3'])->name('equipamento.equipamentoindex3');
    Route::get('/equipa4', [EquipamentoController::class, 'index4'])->name('equipamento.equipamentoindex4');
    Route::get('/equipa5', [EquipamentoController::class, 'index5'])->name('equipamento.equipamentoindex5');
    Route::get('/equipa6', [EquipamentoController::class, 'index6'])->name('equipamento.equipamentoindex6');


    Route::get('/create', [EquipamentoController::class, 'create'])->name('equipamento.equipamentocreate');
    Route::post('/', [EquipamentoController::class, 'store'])->name('equipamento.store');
    Route::get('/{id_equipamento}/edit', [EquipamentoController::class, 'edit'])->where('id_utente', '[0-9]+')->name('equipamento.equipamentoedit');
    Route::put('/{id_equipamento}', [EquipamentoController::class, 'update'])->where('id_utente', '[0-9]+')->name('equipamento.update');
    Route::delete('/{id_equipamento}', [EquipamentoController::class, 'destroy'])->where('id_utente', '[0-9]+')->name('equipamento.destroy');

    
});

Route::view('/equipas', 'equipamento.equipasmenu')->name('equipamento.equipasmenu');

Route::prefix('/despesas')->group(function(){
    Route::get('/', [DespesasController::class, 'index'])->name('despesas.despesasindex');
    Route::get('/create', [DespesasController::class, 'create'])->name('despesas.despesascreate');
    Route::post('/', [DespesasController::class, 'store'])->name('despesas.store');
    Route::get('/{id_despesa}/show', [DespesasController::class, 'show'])->where('id_despesa', '[0-9]+')->name('despesas.despesasshow');
    Route::get('/{id_despesa}/edit', [DespesasController::class, 'edit'])->where('id_despesa', '[0-9]+')->name('despesas.despesasedit');
    Route::put('/{id_despesa}', [DespesasController::class, 'update'])->where('id_despesa', '[0-9]+')->name('despesas.update');
    Route::delete('/{id_despesa}', [DespesasController::class, 'destroy'])->where('id_despesa', '[0-9]+')->name('despesas.destroy');
});




Route::prefix('/triagem')->group(function(){
    Route::get('/', [TriagemController::class, 'index'])->name('menu.triagemindex');
    Route::get('/create', [TriagemController::class, 'create'])->name('menu.triagemcreate');
    Route::post('/', [TriagemController::class, 'store'])->name('triagem.store');
    Route::get('/{id_utente}/show', [TriagemController::class, 'show'])->where('id_utente', '[0-9]+')->name('menu.triagemshow');
    Route::get('/{id_triagem}/edit', [TriagemController::class, 'edit'])->where('id_triagem', '[0-9]+')->name('menu.triagemedit');
    Route::put('/{id_triagem}', [TriagemController::class, 'update'])->where('id_triagem', '[0-9]+')->name('triagem.update');
    Route::delete('/{id_triagem}', [TriagemController::class, 'destroy'])->where('id_triagem', '[0-9]+')->name('triagem.destroy');
});


Route::view('/menuRelatorios', 'menu_relatorios.menuRelatorios')->name('menu_relatorios.menuRelatorios');
Route::view('/gerarRelatorios', 'menu_relatorios.menuRelatorioscreate')->name('menu_relatorios.menuRelatorioscreate');

Route::prefix('/relatorios')->group(function(){
    Route::get('/relatorio_colaboradores', [RelatorioColaboradoresController::class, 'index'])->name('menu_relatorios.relatoriocolaboradoresindex');
    Route::get('/relatorio_colaboradores/create', [RelatorioColaboradoresController::class, 'create'])->name('menu_relatorios.relatoriocolaboradorescreate');
    Route::post('/relatorio_colaboradores', [RelatorioColaboradoresController::class, 'store'])->name('relatoriocolaboradores.store');
    Route::get('/relatorio_colaboradores/{id_relatorio_colab}/show', [RelatorioColaboradoresController::class, 'show'])->where('id_triagem', '[0-9]+')->name('menu_relatorios.relatoriocolaboradoresshow');
    Route::get('/relatorio_colaboradores/{id_relatorio_colab}/edit', [RelatorioColaboradoresController::class, 'edit'])->where('id_triagem', '[0-9]+')->name('menu_relatorios.relatoriocolaboradoresedit');
    Route::put('/relatorio_colaboradores/{id_relatorio_colab}', [RelatorioColaboradoresController::class, 'update'])->where('id_triagem', '[0-9]+')->name('relatoriocolaboradores.update');


    Route::get('/relatorio_consultas', [RelatorioConsultasController::class, 'index'])->name('menu_relatorios.relatorioconsultasindex');
    Route::get('/relatorio_consultas/create', [RelatorioConsultasController::class, 'create'])->name('menu_relatorios.relatorioconsultascreate');
    Route::post('/relatorio_consultas', [RelatorioConsultasController::class, 'store'])->name('relatorioconsultas.store');
    Route::get('/relatorio_consultas/{id_relatorio_consulta}/show', [RelatorioConsultasController::class, 'show'])->where('id_triagem', '[0-9]+')->name('menu_relatorios.relatorioconsultasshow');
    Route::get('/relatorio_consultas/{id_relatorio_consulta}/edit', [RelatorioConsultasController::class, 'edit'])->where('id_triagem', '[0-9]+')->name('menu_relatorios.relatorioconsultasedit');
    Route::put('/relatorio_consultas/{id_relatorio_consulta}', [RelatorioConsultasController::class, 'update'])->where('id_triagem', '[0-9]+')->name('relatorioconsultas.update');

});





 
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
