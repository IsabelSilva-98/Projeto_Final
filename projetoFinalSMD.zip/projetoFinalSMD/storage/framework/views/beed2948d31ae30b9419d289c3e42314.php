



<?php $__env->startSection('title', 'Criação'); ?>




<?php $__env->startSection('content'); ?>

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Adicionar Equipamento</h1>
  <hr>
  <form action="<?php echo e(route('equipamento.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <div class="form-group">
        <label for="nome">Equipamento:</label>
        <input type="text" class="form-control" name="nome" placeholder="Insira o nome do equipamento">
      </div>
      <br>
      <div class="form-group">
        <label for="quantidade">Quantidade:</label>
        <input type="number" class="form-control" name="quantidade" placeholder="Insira a quantidade">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary">
      </div>
    </div>
  </form>
</div>




        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\XAMPP\htdocs\projetoFinalSMD\resources\views/menu_administrativo/equipamentocreate.blade.php ENDPATH**/ ?>