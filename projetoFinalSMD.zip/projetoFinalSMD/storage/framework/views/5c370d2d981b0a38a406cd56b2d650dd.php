



<?php $__env->startSection('title', 'Informação'); ?>




<?php $__env->startSection('content'); ?>

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->

  <div class="container mt-5">
  <h1>Utente</h1>
  <hr>
  <form action="" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
    <div class="form-group">
        <label for="no_utente">Id do Utente:</label>
        <td><?php echo e($utentes->id_utente); ?></td>
      </div>
      <br>
      <div class="form-group">
        <label for="no_utente">Número de Utente:</label>
        <td><?php echo e($utentes->no_utente); ?></td>
      </div>
      <br>
      <div class="form-group">
        <label for="nome">Nome do Utente:</label>
        <td><?php echo e($utentes->nome); ?></td>
      </div>
      <br>
      <div class="form-group">
        <label for="data_nascimento">Data de Nascimento:</label>
        <td><?php echo e($utentes->data_nascimento); ?></td>
      </div>
      <br>
      <div class="form-group">
        <label for="sexo">Sexo:</label>
        <td><?php echo e($utentes->sexo); ?></td>
      </div>
      <br>
      <div class="form-group">
        <label for="email">Email:</label>
        <td><?php echo e($utentes->email); ?></td>
      </div>
      <br>
      <div class="form-group">
        <label for="contacto">Contacto:</label>
        <td><?php echo e($utentes->contacto); ?></td>
      </div>
      <br>
      <a href="<?php echo e(route('menu.utentesindex')); ?>" class="btn btn-success">Lista de Utentes</a>
      <a href="<?php echo e(route('menu.triagemshow', ['id_utente'=>$utentes->id_utente])); ?>"class="btn btn-success">Triagem</a>
    </div>
  </form>
</div>




        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\XAMPP\htdocs\projetoFinalSMD\resources\views/menu/utentesshow.blade.php ENDPATH**/ ?>