



<?php $__env->startSection('title', 'Informação'); ?>




<?php $__env->startSection('content'); ?>

<div class="container mt-5">
  <h1>Lista de Equipas: </h1>
  <hr>
  <form action="">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <div class="form-group">
        <label for="descricao">Equipa 1</label>
        <a href="<?php echo e(route('equipamento.equipamentoindex1')); ?>" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 2</label>
        <a href="<?php echo e(route('equipamento.equipamentoindex2')); ?>" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 3</label>
        <a href="<?php echo e(route('equipamento.equipamentoindex3')); ?>" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 4</label>
        <a href="<?php echo e(route('equipamento.equipamentoindex4')); ?>" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 5</label>
        <a href="<?php echo e(route('equipamento.equipamentoindex5')); ?>" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 6</label>
        <a href="<?php echo e(route('equipamento.equipamentoindex6')); ?>" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
    </div>
  </form>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\XAMPP\htdocs\projetoFinalSMD\resources\views/equipamento/equipasmenu.blade.php ENDPATH**/ ?>