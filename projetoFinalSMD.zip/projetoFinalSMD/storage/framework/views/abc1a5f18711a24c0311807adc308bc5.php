



<?php $__env->startSection('title', 'Criação'); ?>




<?php $__env->startSection('content'); ?>

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Nova consulta</h1>
  <hr>
  <form action="<?php echo e(route('consulta.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <input type="text" class="form-control" name="nome_utente" placeholder="Insira o nome completo">
      </div>
      <br>
      <div class="form-group">
        <label for="id_utente">Id do Utente:</label>
        <input type="number" class="form-control" name="id_utente">
      </div>
      <br>
      <div class="form-group">
        <label for="data">Data:</label>
        <input type="date" class="form-control" name="data">
      </div>
      <br>
      <div class="form-group">
        <label for="diagnostico">Diagnóstico:</label>
        <input type="text" class="form-control" name="diagnostico" placeholder="Insira o diagnóstico">
      </div>
      <br>
      <div class="form-group">
        <label for="antecedentes">Antecedentes de Saúde:</label>
        <input type="text" class="form-control" name="antecedentes" placeholder="Insira os antecedentes ">
      </div>
      <br>
      <div class="form-group">
        <label for="medicacao">Medicação do Utente:</label>
        <input type="text" class="form-control" name="medicacao" placeholder="Insira os medicamentos ">
      </div>
      <br>
      <div class="form-group">
        <label for="id_equipa">Id da Equipa:</label>
        <input type="number" class="form-control" name="id_equipa" placeholder="Insira o número da equipa">
      </div>
      <br>
      <div class="form-group">
        <label for="id_triagem">Id da triagem:</label>
        <input type="number" class="form-control" name="id_triagem">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary">
      </div>
    </div>
  </form>
</div>




        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\XAMPP\htdocs\projetoFinalSMD\resources\views/menu_doutor/consultascreate.blade.php ENDPATH**/ ?>