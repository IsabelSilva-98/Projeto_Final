



<?php $__env->startSection('title', 'Lista'); ?>




<?php $__env->startSection('content'); ?>

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->


<div class="container mt-5">
  <div class="row">
    <div class="col-sm-8">
      <h1>Calendário</h1>
      <nav class="navbar navbar-light bg-light">
        <form class="form-inline" type='get' action="">
          <input class="form-control mr-sm-2" type="search" placeholder="Procurar" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Procurar</button>
        </form>
      </nav>
    </div>

    <div class="col-sm-4">
      <a href="<?php echo e(route('calendario.calendariocreate')); ?>" class="btn btn-primary">Agendar Consulta</a>
    </div>

  </div>
  <br>

<div class="table-responsive">
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#Id</th>
      <th scope="col">Nome do Utente</th>
      <th scope="col">Dia</th>
      <th scope="col">Hora</th>
      <th scope="col">Equipa</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $calendario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calendario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th><?php echo e($calendario->id_utente); ?></th>
        <td><?php echo e($calendario->nome_utente); ?></td>
        <th><?php echo e($calendario->dia); ?></th>
        <th><?php echo e($calendario->hora); ?></th>
        <th><?php echo e($calendario->id_equipa); ?></th>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>




  
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\XAMPP\htdocs\projetoFinalSMD\resources\views/calendario/calendarioindex.blade.php ENDPATH**/ ?>