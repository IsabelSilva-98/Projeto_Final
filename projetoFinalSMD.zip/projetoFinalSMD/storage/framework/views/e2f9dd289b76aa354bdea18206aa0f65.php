<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
</head>
<body>
    <h1>Menu</h1>

    <a href="<?php echo e(route('menu_doutor.consultascreate')); ?>">Registar Consulta</a>
    <br>
    <a href="<?php echo e(route('menu_doutor.consultasindex')); ?>">Lista de Consultas</a>
    <br>
    <a href="<?php echo e(route('menu_administrativo.utentesindex')); ?>">Lista de Utentes</a>
    <br>
    <a href="<?php echo e(route('calendario.calendarioindex')); ?>">Calendário</a>
    <br>
    <a href="<?php echo e(route('menu_relatorios.menuRelatorios')); ?>">Relatórios</a>
</body>
</html><?php /**PATH C:\Users\HP\Desktop\XAMPP\htdocs\projetoFinalSMD\resources\views/menu_doutor/menuDoutor.blade.php ENDPATH**/ ?>