



<?php $__env->startSection('title', 'Criação'); ?>




<?php $__env->startSection('content'); ?>

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Adicionar Utente</h1>
  <hr>
  <form action="<?php echo e(route('utente.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <div class="form-group">
        <label for="no_utente">Número de Utente:</label>
        <input type="number" class="form-control" name="no_utente" placeholder="Insira o número de utente">
      </div>
      <br>
      <div class="form-group">
        <label for="nome">Nome do Utente:</label>
        <input type="text" class="form-control" name="nome" placeholder="Insira o nome do utente">
      </div>
      <br>
      <div class="form-group">
        <label for="data_nascimento">Data de Nascimento:</label>
        <input type="date" class="form-control" name="data_nascimento">
      </div>
      <br>
      <div class="form-group">
        <label for="sexo">Sexo:</label>
        <br>
        <input type="radio" id="sexo-masculino" name="sexo" value="masculino">
        <label for="sexo-masculino">Masculino</label>
    
        <input type="radio" id="sexo-feminino" name="sexo" value="feminino">
        <label for="sexo-feminino">Feminino</label>
      </div>
      <br>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" name="email" placeholder="Insira o email">
      </div>
      <br>
      <div class="form-group">
        <label for="contacto">Contacto:</label>
        <input type="number" class="form-control" name="contacto" placeholder="Insira o contacto">
      </div>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary">
      </div>
    </div>
  </form>
</div>




        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\XAMPP\htdocs\projetoFinalSMD\resources\views/menu_administrativo/utentescreate.blade.php ENDPATH**/ ?>