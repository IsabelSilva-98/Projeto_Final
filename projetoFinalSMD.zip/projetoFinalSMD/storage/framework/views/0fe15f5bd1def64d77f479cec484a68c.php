



<?php $__env->startSection('title', 'Informação'); ?>




<?php $__env->startSection('content'); ?>

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Triagem</h1>
  <hr>
  <form action="">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <div class="form-group">
        <label for="nome_utente">Id da Triagem:</label>
        <th><?php echo e($triagem->id_triagem); ?></th>
      </div>
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <th><?php echo e($triagem->nome_utente); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="nome_utente">Id do Utente:</label>
        <th><?php echo e($triagem->id_utente); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="peso">Peso:</label>
        <th><?php echo e($triagem->peso); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="altura">Altura:</label>
        <th><?php echo e($triagem->altura); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="colestrol">Colesterol:</label>
        <th><?php echo e($triagem->colestrol); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="glicose">Glicose:</label>
        <th><?php echo e($triagem->glicose); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_diastolica">Tensão Diastólica:</label>
        <th><?php echo e($triagem->tensao_diastolica); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_sistolica">Tensão Sistólica:</label>
        <th><?php echo e($triagem->tensao_sistolica); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_utente">Id do Utente:</label>
        <th><?php echo e($triagem->id_utente); ?></th>
      </div>
      <a href="<?php echo e(route('menu_enfermeira.triagemindex')); ?>" class="btn btn-success">Lista de Triagens</a>
      <a href="<?php echo e(route('menu_administrativo.utentesshow', ['id_utente'=>$triagem->id_utente])); ?>"class="btn btn-success">Utente</a>
    </div>
  </form>
</div>




        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\XAMPP\htdocs\projetoFinalSMD\resources\views/menu_enfermeira/triagemshow.blade.php ENDPATH**/ ?>