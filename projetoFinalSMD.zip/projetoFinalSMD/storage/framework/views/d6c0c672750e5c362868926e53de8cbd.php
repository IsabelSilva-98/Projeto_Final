



<?php $__env->startSection('title', 'Informação'); ?>




<?php $__env->startSection('content'); ?>

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Consulta</h1>
  <hr>
  <form action="">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <div class="form-group">
        <label for="id_consulta">Id da Consulta:</label>
        <th><?php echo e($consultas->id_consulta); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="data">Data:</label>
        <th><?php echo e($consultas->data); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <th><?php echo e($consultas->nome_utente); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_utente">Id do Utente:</label>
        <th><?php echo e($consultas->id_utente); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="diagnostico">Diagnótico:</label>
        <th><?php echo e($consultas->diagnostico); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="antecedentes">Antecedentes:</label>
        <th><?php echo e($consultas->antecedentes); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="medicacao">Medicação:</label>
        <th><?php echo e($consultas->medicacao); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_triagem">Id da Triagem:</label>
        <th><?php echo e($consultas->id_triagem); ?></th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_equipa">Id da Equipa:</label>
        <th><?php echo e($consultas->id_equipa); ?></th>
      </div>
      <a href="<?php echo e(route('menu_doutor.consultasindex')); ?>" class="btn btn-success">Lista de Consultas</a>
      <a href="<?php echo e(route('menu_enfermeira.triagemshow', ['id_utente'=>$consultas->id_utente])); ?>"class="btn btn-success">Triagem</a>
    </div>
  </form>
</div>




        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\XAMPP\htdocs\projetoFinalSMD\resources\views/menu_doutor/consultasshow.blade.php ENDPATH**/ ?>