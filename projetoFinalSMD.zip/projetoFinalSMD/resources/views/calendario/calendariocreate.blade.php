@extends('layouts.app')



@section('title', 'Criação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Agendar nova Consulta</h1>
  <hr>
  <form action="{{route('calendario.store')}}" method="POST">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <input type="text" class="form-control" name="nome_utente" placeholder="Insira o nome do utente">
      </div>
      <br>
      <div class="form-group">
        <label for="dia">Dia:</label>
        <input type="date" class="form-control" name="dia">
      </div>
      <br>
      <div class="form-group">
        <label for="hora">Hora:</label>
        <input type="time" class="form-control" name="hora">
      </div>
      <br>
      <div class="form-group">
        <label for="localizacao">Localização:</label>
        <input type="text" class="form-control" name="localizacao" placeholder="Insira a localização">
      </div>
      <br>
      <div class="form-group">
        <label for="id_equipa">Equipa:</label>
        <input type="number" class="form-control" name="id_equipa" placeholder="Insira o id da equipa">
      </div>
      <br>
      <div class="form-group">
        <label for="id_utente">Id do Utente:</label>
        <input type="number" class="form-control" name="id_utente" placeholder="Insira o id do utente">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary">
      </div>
    </div>
  </form>
</div>




        

@endsection