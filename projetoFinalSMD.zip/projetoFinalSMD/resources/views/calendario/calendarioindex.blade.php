@extends('layouts.app')



@section('title', 'Lista')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->


<div class="container mt-5">
  <div class="row">
    <div class="col-sm-8">
      <h1>Calendário</h1>
      <nav class="navbar navbar-light bg-light">
        <form class="form-inline" type='get' action="">
          <input class="form-control mr-sm-2" type="search" placeholder="Procurar" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Procurar</button>
        </form>
      </nav>
    </div>

    <div class="col-sm-4">
      <a href="{{route('calendario.calendariocreate')}}" class="btn btn-primary">Agendar Consulta</a>
    </div>

  </div>
  <br>

<div class="table-responsive">
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#Id</th>
      <th scope="col">Nome do Utente</th>
      <th scope="col">Dia</th>
      <th scope="col">Hora</th>
      <th scope="col">Equipa</th>
    </tr>
  </thead>
  <tbody>
    @foreach($calendario as $calendario)
      <tr>
        <th>{{$calendario->id_utente}}</th>
        <td>{{$calendario->nome_utente}}</td>
        <th>{{$calendario->dia}}</th>
        <th>{{$calendario->hora}}</th>
        <th>{{$calendario->id_equipa}}</th>
      </tr>
    @endforeach
  </tbody>
</table>




  
</div>



@endsection