@extends('layouts.app')



@section('title', 'Edição')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Editar</h1>
  <hr>
  <form action="{{ route('triagem.update', ['id_triagem'=>$triagem->id_triagem]) }}" method="POST">
    @csrf
    @method('PUT')
    <div class="form-group">
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <input type="text" class="form-control" name="nome" value="{{$triagem->nome_utente}}" placeholder="Insira o nome do utente">
      </div>
      <br>
      <div class="form-group">
        <label for="id_utente">Id do Utente:</label>
        <input type="number" class="form-control" name="id_utente" value="{{$triagem->id_utente}}" placeholder="Insira o id do utente">
      </div>
      <br>
      <div class="form-group">
        <label for="peso">Peso:</label>
        <input type="number" class="form-control" name="peso" value="{{$triagem->peso}}" placeholder="Insira o peso">
      </div>
      <br>
      <div class="form-group">
        <label for="altura">Altura:</label>
        <input type="number" class="form-control" name="altura" value="{{$triagem->altura}}" placeholder="Insira a altura">
      </div>
      <br>
      <div class="form-group">
        <label for="colestrol">Colesterol:</label>
        <input type="number" class="form-control" name="colestrol" value="{{$triagem->colestrol}}" placeholder="Insira o valor do colestrol">
      </div>
      <br>
      <div class="form-group">
        <label for="glicose">Glicose:</label>
        <input type="number" class="form-control" name="glicose" value="{{$triagem->glicose}}" placeholder="Insira o valor da glicose">
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_diastolica">Tensão Diastólica:</label>
        <input type="number" class="form-control" name="tensao_diastolica" value="{{$triagem->tensao_diastolica}}" placeholder="Insira o valor da tensão diastólica">
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_sistolica">Tensão Sistólica:</label>
        <input type="number" class="form-control" name="tensao_sistolica" value="{{$triagem->tensao_sistolica}}" placeholder="Insira o valor da tensão sistólica">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary" value="Atualizar">
      </div>
    </div>
  </form>
</div>




        

@endsection