@extends('layouts.app')



@section('title', 'Criação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Nova consulta</h1>
  <hr>
  <form action="{{route('consulta.store')}}" method="POST">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <input type="text" class="form-control" name="nome_utente" placeholder="Insira o nome completo">
      </div>
      <br>
      <div class="form-group">
        <label for="id_utente">Id do Utente:</label>
        <input type="number" class="form-control" name="id_utente">
      </div>
      <br>
      <div class="form-group">
        <label for="data">Data:</label>
        <input type="date" class="form-control" name="data">
      </div>
      <br>
      <div class="form-group">
        <label for="diagnostico">Diagnóstico:</label>
        <input type="text" class="form-control" name="diagnostico" placeholder="Insira o diagnóstico">
      </div>
      <br>
      <div class="form-group">
        <label for="antecedentes">Antecedentes de Saúde:</label>
        <input type="text" class="form-control" name="antecedentes" placeholder="Insira os antecedentes ">
      </div>
      <br>
      <div class="form-group">
        <label for="medicacao">Medicação do Utente:</label>
        <input type="text" class="form-control" name="medicacao" placeholder="Insira os medicamentos ">
      </div>
      <br>
      <div class="form-group">
        <label for="id_equipa">Id da Equipa:</label>
        <input type="number" class="form-control" name="id_equipa" placeholder="Insira o número da equipa">
      </div>
      <br>
      <div class="form-group">
        <label for="id_triagem">Id da triagem:</label>
        <input type="number" class="form-control" name="id_triagem">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary">
      </div>
    </div>
  </form>
</div>




        

@endsection