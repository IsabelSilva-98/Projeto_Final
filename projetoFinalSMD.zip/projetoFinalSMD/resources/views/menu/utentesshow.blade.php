@extends('layouts.app')



@section('title', 'Informação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->

  <div class="container mt-5">
  <h1>Utente</h1>
  <hr>
  <form action="" method="POST">
    @csrf
    <div class="form-group">
    <div class="form-group">
        <label for="no_utente">Id do Utente:</label>
        <td>{{$utentes->id_utente}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="no_utente">Número de Utente:</label>
        <td>{{$utentes->no_utente}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="nome">Nome do Utente:</label>
        <td>{{$utentes->nome}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="data_nascimento">Data de Nascimento:</label>
        <td>{{$utentes->data_nascimento}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="sexo">Sexo:</label>
        <td>{{$utentes->sexo}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="email">Email:</label>
        <td>{{$utentes->email}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="contacto">Contacto:</label>
        <td>{{$utentes->contacto}}</td>
      </div>
      <br>
      <a href="{{ route('menu.utentesindex') }}" class="btn btn-success">Lista de Utentes</a>
      <a href="{{ route('menu.triagemshow', ['id_utente'=>$utentes->id_utente])}}"class="btn btn-success">Triagem</a>
    </div>
  </form>
</div>




        

@endsection