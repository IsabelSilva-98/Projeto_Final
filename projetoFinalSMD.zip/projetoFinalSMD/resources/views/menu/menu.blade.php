<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
</head>
<body>
    <h1>Menu</h1>


    <a href="{{route('menu.utentesindex')}}">Lista de Utentes</a>
    <br>
    <a href="{{route('menu.consultasindex')}}">Lista de Consultas</a>
    <br>
    <a href="{{route('menu.triagemindex')}}">Lista de Triagens</a>
    <br>
    <a href="{{Route('menu.funcionariosindex')}}">Lista de Funcionários</a>
    <br>
    <a href="{{route('calendario.calendarioindex')}}">Calendário</a>
    <br>
    <a href="{{route('menu_relatorios.menuRelatorios')}}">Relatórios</a>
    <br>
    <a href="{{route('equipamento.equipasmenu')}}">Equipamento</a>
    <br>
    <a href="{{route('despesas.despesasindex')}}">Despesas</a>



    
</body>
</html>