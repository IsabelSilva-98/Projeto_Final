@extends('layouts.app')



@section('title', 'Informação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Consulta</h1>
  <hr>
  <form action="">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="id_consulta">Id da Consulta:</label>
        <th>{{$consultas->id_consulta}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="data">Data:</label>
        <th>{{$consultas->data}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <th>{{$consultas->nome_utente}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_utente">Id do Utente:</label>
        <th>{{$consultas->id_utente}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="diagnostico">Diagnótico:</label>
        <th>{{$consultas->diagnostico}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="antecedentes">Antecedentes:</label>
        <th>{{$consultas->antecedentes}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="medicacao">Medicação:</label>
        <th>{{$consultas->medicacao}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_triagem">Id da Triagem:</label>
        <th>{{$consultas->id_triagem}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_equipa">Id da Equipa:</label>
        <th>{{$consultas->id_equipa}}</th>
      </div>
      <a href="{{ route('menu.consultasindex') }}" class="btn btn-success">Lista de Consultas</a>
      <a href="{{ route('menu.triagemshow', ['id_utente'=>$consultas->id_utente])}}"class="btn btn-success">Triagem</a>
    </div>
  </form>
</div>




        

@endsection