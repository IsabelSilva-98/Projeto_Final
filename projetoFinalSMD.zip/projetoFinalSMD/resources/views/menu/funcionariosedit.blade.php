@extends('layouts.app')



@section('title', 'Edição')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Editar</h1>
  <hr>
  <form action="{{ route('funcionarios.update', ['id_user'=>$funcionarios->id_user]) }}" method="POST">
    @csrf
    @method('PUT')
    <div class="form-group">
        <label for="nome">Nome do Funcionário:</label>
        <input type="text" class="form-control" name="nome" value="{{$funcionarios->nome}}" placeholder="Insira o nome do funcionário">
      </div>
      <br>
      <div class="form-group">
        <label for="data_nascimento">Data de Nascimento:</label>
        <input type="date" class="form-control" name="data_nascimento" value="{{$funcionarios->data_nascimento}}">
      </div>
      <br>
      <div class="form-group">
        <label for="sexo">Sexo:</label>
        <br>
        <input type="radio" id="sexo-masculino" name="sexo" value="masculino">
        <label for="sexo-masculino">Masculino</label>
    
        <input type="radio" id="sexo-feminino" name="sexo" value="feminino">
        <label for="sexo-feminino">Feminino</label>
      </div>
      <br>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" name="email" value="{{$funcionarios->email}}" placeholder="Insira o email">
      </div>
      <br>
      <div class="form-group">
        <label for="contacto">Contacto:</label>
        <input type="number" class="form-control" name="contacto" value="{{$funcionarios->contacto}}" placeholder="Insira o contacto">
      </div>
      <br>
      <div class="form-group">
        <label for="id_funcao">Id da Função:</label>
        <input type="number" class="form-control" name="id_funcao" value="{{$funcionarios->id_funcao}}" placeholder="Insira o id da função">
      </div>
      <br>
      <div class="form-group">
        <label for="id_equipa">Id da Equipa:</label>
        <input type="number" class="form-control" name="id_equipa" value="{{$funcionarios->id_equipa}}" placeholder="Insira o id da equipa">
      </div>
      <br>
      <div class="form-group">
        <label for="funcao">Função:</label>
        <input type="text" class="form-control" name="funcao" value="{{$funcionarios->funcao}}" placeholder="Insira a sua função">
      </div>
      <br>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="text" class="form-control" name="password" value="{{$funcionarios->password}}" placeholder="Insira uma password">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary" value="Atualizar">
      </div>
    </div>
  </form>
</div>




        

@endsection