@extends('layouts.app')



@section('title', 'Informação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Triagem</h1>
  <hr>
  <form action="">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="nome_utente">Id da Triagem:</label>
        <th>{{$triagem->id_triagem}}</th>
      </div>
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <th>{{$triagem->nome_utente}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="nome_utente">Id do Utente:</label>
        <th>{{$triagem->id_utente}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="peso">Peso:</label>
        <th>{{$triagem->peso}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="altura">Altura:</label>
        <th>{{$triagem->altura}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="colestrol">Colesterol:</label>
        <th>{{$triagem->colestrol}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="glicose">Glicose:</label>
        <th>{{$triagem->glicose}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_diastolica">Tensão Diastólica:</label>
        <th>{{$triagem->tensao_diastolica}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_sistolica">Tensão Sistólica:</label>
        <th>{{$triagem->tensao_sistolica}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_utente">Id do Utente:</label>
        <th>{{$triagem->id_utente}}</th>
      </div>
      <a href="{{ route('menu.triagemindex') }}" class="btn btn-success">Lista de Triagens</a>
      <a href="{{ route('menu.utentesshow', ['id_utente'=>$triagem->id_utente])}}"class="btn btn-success">Utente</a>
    </div>
  </form>
</div>




        

@endsection