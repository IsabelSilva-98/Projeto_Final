@extends('layouts.app')



@section('title', 'Informação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->

  <div class="container mt-5">
  <h1>Utente</h1>
  <hr>
  <form action="" method="POST">
    @csrf
    <div class="form-group">
    <div class="form-group">
        <label for="id_funcionario">Id do Funcionário:</label>
        <td>{{$funcionarios->id_utente}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="nome">Nome do Funcionário:</label>
        <td>{{$funcionarios->nome}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="data_nascimento">Data de Nascimento:</label>
        <td>{{$funcionarios->data_nascimento}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="sexo">Sexo:</label>
        <td>{{$funcionarios->sexo}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="email">Email:</label>
        <td>{{$funcionarios->email}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="contacto">Contacto:</label>
        <td>{{$funcionarios->contacto}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="id_funcao">Id da Função:</label>
        <td>{{$funcionarios->id_funcao}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="id_equipa">Id da Equipa:</label>
        <td>{{$funcionarios->id_equipa}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="funcao">Função:</label>
        <td>{{$funcionarios->funcao}}</td>
      </div>
      <br>
      <div class="form-group">
        <label for="password">Password:</label>
        <td>{{$funcionarios->password}}</td>
      </div>
      <br>
      <a href="{{ route('menu.funcionariosindex') }}" class="btn btn-success">Lista de Funcionários</a>
  </form>
</div>




        

@endsection