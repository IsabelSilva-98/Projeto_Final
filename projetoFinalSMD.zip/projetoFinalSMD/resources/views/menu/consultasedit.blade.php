@extends('layouts.app')



@section('title', 'Edição')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Editar</h1>
  <hr>
  <form action="{{ route('consultas.update', ['id_consulta'=>$consultas->id_consulta]) }}" method="POST">
    @csrf
    @method('PUT')
    <div class="form-group">
      <div class="form-group">
        <label for="nome">Nome do Utente:</label>
        <input type="text" class="form-control" name="nome" value="{{$consultas->nome_utente}}" placeholder="Insira o nome do utente">
      </div>
      <br>
      <div class="form-group">
        <label for="peso">Id do Utente:</label>
        <input type="number" class="form-control" name="peso" value="{{$consultas->id_utente}}" placeholder="Insira o id do utente">
      </div>
      <br>
      <div class="form-group">
        <label for="data">Data:</label>
        <input type="date" class="form-control" name="data" value="{{$consultas->data}}" placeholder="Insira a data">
      </div>
      <br>
      <div class="form-group">
        <label for="diagnostico">Diagnóstico:</label>
        <input type="text" class="form-control" name="diagnostico" value="{{$consultas->diagnostico}}" placeholder="Insira o diagnostico">
      </div>
      <br>
      <div class="form-group">
        <label for="antecedentes">Antecedentes:</label>
        <input type="text" class="form-control" name="antecedentes" value="{{$consultas->antecedentes}}" placeholder="Insira os antecedentes">
      </div>
      <br>
      <div class="form-group">
        <label for="medicacao">Medicação:</label>
        <input type="text" class="form-control" name="medicacao" value="{{$consultas->medicacao}}" placeholder="Insira a medicalão">
      </div>
      <br>
      <div class="form-group">
        <label for="id_triagem">Id da Triagem:</label>
        <input type="number" class="form-control" name="id_triagem" value="{{$consultas->id_triagem}}" placeholder="Insira o id da triagem">
      </div>
      <br>
      <div class="form-group">
        <label for="id_equipa">Id da Equipa:</label>
        <input type="number" class="form-control" name="id_equipa" value="{{$consultas->id_equipa}}" placeholder="Insira o is da equipa">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary" value="Atualizar">
      </div>
    </div>
  </form>
</div>




        

@endsection