@extends('layouts.app')



@section('title', 'Criação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Adicionar Triagem</h1>
  <hr>
  <form action="{{route('triagem.store')}}" method="POST">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <input type="text" class="form-control" name="nome_utente" placeholder="Insira o nome completo">
      </div>
      <br>
      <div class="form-group">
        <label for="peso">Peso:</label>
        <input type="number" class="form-control" name="peso" placeholder="Insira o peso">
      </div>
      <br>
      <div class="form-group">
        <label for="altura">Altura:</label>
        <input type="text" class="form-control" name="altura" placeholder="Insira a altura">
      </div>
      <br>
      <div class="form-group">
        <label for="colestrol">Colesterol:</label>
        <input type="number" class="form-control" name="colestrol" placeholder="Insira o valor do colestrol">
      </div>
      <br>
      <div class="form-group">
        <label for="glicose">Glicose:</label>
        <input type="number" class="form-control" name="glicose" placeholder="Insira o valor da glicose">
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_diastolica">Tensão Diastólica:</label>
        <input type="number" class="form-control" name="tensao_diastolica" placeholder="Insira o valor da tensão diastólica">
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_sistolica">Tensão Sistólica:</label>
        <input type="number" class="form-control" name="tensao_sistolica" placeholder="Insira o valor da tensão sistólica">
      </div>
      <br>
      <div class="form-group">
        <label for="id_utente">Id do Utente:</label>
        <input type="number" class="form-control" name="id_utente" placeholder="Insira o id do utente">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary">
      </div>
    </div>
  </form>
</div>




        

@endsection