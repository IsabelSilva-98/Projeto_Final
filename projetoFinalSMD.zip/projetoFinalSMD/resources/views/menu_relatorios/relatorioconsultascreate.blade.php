@extends('layouts.app')



@section('title', 'Criação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Novo Relatório de Consultas</h1>
  <hr>
  <form action="{{route('relatorioconsultas.store')}}" method="POST">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="data">Data:</label>
        <input type="date" class="form-control" name="data">
      </div>
      <br>
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <input type="text" class="form-control" name="nome_utente" placeholder="Insira o nome do utente">
      </div>
      <br>
      <div class="form-group">
        <label for="id_consulta">Id da Consulta:</label>
        <input type="number" class="form-control" name="id_consulta" placeholder="Insira o id da consulta">
      </div>
      <br>
      <div class="form-group">
        <label for="diagnostico">Diagnóstico:</label>
        <input type="text" class="form-control" name="diagnostico" placeholder="Insira o diagnóstico">
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_diastolica">Tensão Diastólica:</label>
        <input type="number" class="form-control" name="tensao_diastolica" placeholder="Insira o valor da tensão diastólica">
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_sistolica">Tensão Sistólica:</label>
        <input type="text" class="form-control" name="tensao_sistolica" placeholder="Insira o valor da tensão sistólica">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary">
      </div>
    </div>
  </form>
</div>




        

@endsection