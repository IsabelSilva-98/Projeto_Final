@extends('layouts.app')



@section('title', 'Edição')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Editar</h1>
  <hr>
  <form action="{{ route('relatoriocolaboradores.update', ['id_relatorio_colab'=>$relatoriocolab->id_relatorio_colab]) }}" method="POST">
    @csrf
    @method('PUT')
    <div class="form-group">
      <div class="form-group">
        <label for="data">Data:</label>
        <input type="date" class="form-control" name="data">
      </div>
      <br>
      <div class="form-group">
        <label for="nome_colaborador">Nome do Colaborador:</label>
        <input type="text" class="form-control" name="nome_colaborador" placeholder="Insira o nome do colaborador">
      </div>
      <br>
      <div class="form-group">
        <label for="id_funcionario">Id do Colaborador:</label>
        <input type="number" class="form-control" name="id_funcionario" placeholder="Insira o id do colaborador">
      </div>
      <br>
      <div class="form-group">
        <label for="salario">Salário:</label>
        <input type="text" class="form-control" name="salario" placeholder="Insira o salario">
      </div>
      <br>
      <div class="form-group">
        <label for="funcao">Função:</label>
        <input type="text" class="form-control" name="funcao" placeholder="Insira o função ">
      </div>
      <br>
      <div class="form-group">
        <label for="equipa">Equipa:</label>
        <input type="text" class="form-control" name="equipa" placeholder="Insira a equipa">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary" value="Atualizar">
      </div>
    </div>
  </form>
</div>




        

@endsection