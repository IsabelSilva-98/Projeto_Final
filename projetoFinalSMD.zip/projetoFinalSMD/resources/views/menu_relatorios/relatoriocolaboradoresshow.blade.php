@extends('layouts.app')



@section('title', 'Informação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Relatório</h1>
  <hr>
  <form action="">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="data">Data:</label>
        <th>{{$relatoriocolab->data}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="nome_colaborador">Nome do Colaborador:</label>
        <th>{{$relatoriocolab->nome_colaborador}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_funcionario">Id do Colaborador:</label>
        <th>{{$relatoriocolab->id_funcionario}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="salario">Salário:</label>
        <th>{{$relatoriocolab->salario}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="funcao">Função:</label>
        <th>{{$relatoriocolab->funcao}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="equipa">Equipa:</label>
        <th>{{$relatoriocolab->equipa}}</th>
      </div>
      <br>
      <a href="{{ route('menu_relatorios.relatoriocolaboradoresindex') }}" class="btn btn-success">Lista de Relatórios</a>
    </div>
  </form>
</div>




        

@endsection