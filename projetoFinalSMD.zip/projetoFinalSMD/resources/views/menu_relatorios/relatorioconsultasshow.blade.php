@extends('layouts.app')



@section('title', 'Informação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Relatório</h1>
  <hr>
  <form action="">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="data">Data:</label>
        <th>{{$relatorioconsulta->data}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="nome_utente">Nome do Utente:</label>
        <th>{{$relatorioconsulta->nome_utente}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_consulta">Id da Consulta:</label>
        <th>{{$relatorioconsulta->id_consulta}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="diagnostico">Diagnóstico:</label>
        <th>{{$relatorioconsulta->diagnostico}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_diastolica">Tensão Diastólica:</label>
        <th>{{$relatorioconsulta->tensao_diastolica}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="tensao_sistolica">Tensão Sistólica:</label>
        <th>{{$relatorioconsulta->tensao_sistolica}}</th>
      </div>
      <br>
      <a href="{{ route('menu_relatorios.relatorioconsultasindex') }}" class="btn btn-success">Lista de Relatórios</a>
    </div>
  </form>
</div>




        

@endsection