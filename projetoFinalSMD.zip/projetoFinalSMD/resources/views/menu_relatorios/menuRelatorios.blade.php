<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
</head>
<body>
    <h1>Menu</h1>

    <a href="{{route('menu_relatorios.relatoriocolaboradoresindex')}}">Relatório de Colaboradores</a>
    <br>
    <a href="{{route('menu_relatorios.relatorioconsultasindex')}}">Relatório de Consultas</a>
</body>
</html>