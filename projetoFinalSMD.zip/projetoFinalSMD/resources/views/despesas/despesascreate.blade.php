@extends('layouts.app')



@section('title', 'Criação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Adicionar Despesa</h1>
  <hr>
  <form action="{{route('despesas.store')}}" method="POST">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="data">Data:</label>
        <input type="date" class="form-control" name="data">
      </div>
      <br>
      <div class="form-group">
        <label for="combustivel">Combustível:</label>
        <input type="text" class="form-control" name="combustivel" placeholder="Insira o valor do combustível">
      </div>
      <br>
      <div class="form-group">
        <label for="mapa_km">Mapa de KM:</label>
        <input type="text" class="form-mapa_km" name="data_nascimento" placeholder="Insira o mapa de km">
      </div>
      <br>
      <div class="form-group">
        <label for="portagens">Portagens:</label>
        <input type="text" class="form-control" name="portagens" placeholder="Insira o valor das portagens">
      </div>
      <br>
      <div class="form-group">
        <label for="id_funcionario">Id do Funcionário:</label>
        <input type="number" class="form-control" name="id_funcionario" placeholder="Insira o id do funcionário">
      </div>
      <br>
      <div class="form-group">
        <label for="equipa">Equipa:</label>
        <input type="number" class="form-control" name="equipa" placeholder="Insira a equipa">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary">
      </div>
    </div>
  </form>
</div>




        

@endsection