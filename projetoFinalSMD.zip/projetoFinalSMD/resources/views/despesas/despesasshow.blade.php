@extends('layouts.app')



@section('title', 'Informação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Despesa</h1>
  <hr>
  <form action="">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="id_despesa">Id da Despesa:</label>
        <th>{{$despesas->id_despesa}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="data">Data:</label>
        <th>{{$despesas->data}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="combustivel">Combustível:</label>
        <th>{{$despesas->combustivel}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="mapa_km">Mapa de Km:</label>
        <th>{{$despesas->mapa_km}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="portagens">Portagens:</label>
        <th>{{$despesas->portagens}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="id_funcionario">Id do Funcionário:</label>
        <th>{{$despesas->id_funcionario}}</th>
      </div>
      <br>
      <div class="form-group">
        <label for="equipa">Equipa:</label>
        <th>{{$despesas->equipa}}</th>
      </div>
      <br>
      <a href="{{ route('despesas.despesasindex') }}" class="btn btn-success">Voltar</a>
    </div>
  </form>
</div>




        

@endsection