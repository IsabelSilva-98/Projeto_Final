@extends('layouts.app')



@section('title', 'Edição')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Editar</h1>
  <hr>
  <form action="{{ route('equipamento.update', ['id_equipamento'=>$equipamento->id_equipamento]) }}" method="POST">
    @csrf
    @method('PUT')
    <div class="form-group">
      <div class="form-group">
        <label for="nome">Número de Utente:</label>
        <input type="text" class="form-control" name="nome" value="{{$equipamento->nome}}" placeholder="Insira o nome do equipamento">
      </div>
      <br>
      <div class="form-group">
        <label for="quantidade">Quantidade:</label>
        <input type="number" class="form-control" name="quantidade" value="{{$equipamento->quantidade}}" placeholder="Insira a quantidade">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary" value="Atualizar">
      </div>
    </div>
  </form>
</div>




        

@endsection