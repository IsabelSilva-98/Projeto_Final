@extends('layouts.app')



@section('title', 'Informação')




@section('content')

<div class="container mt-5">
  <h1>Lista de Equipas: </h1>
  <hr>
  <form action="">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="descricao">Equipa 1</label>
        <a href="{{route('equipamento.equipamentoindex1')}}" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 2</label>
        <a href="{{route('equipamento.equipamentoindex2')}}" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 3</label>
        <a href="{{route('equipamento.equipamentoindex3')}}" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 4</label>
        <a href="{{route('equipamento.equipamentoindex4')}}" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 5</label>
        <a href="{{route('equipamento.equipamentoindex5')}}" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
      <div class="form-group">
        <label for="descricao">Equipa 6</label>
        <a href="{{route('equipamento.equipamentoindex6')}}" class="btn btn-primary">Lista de Equipamentos</a>

      </div>
      <br>
    </div>
  </form>
</div>

@endsection


