@extends('layouts.app')



@section('title', 'Criação')




@section('content')

<!-- Tudo o que está aqi dentro vai ser renderizado no nosso template -->
<div class="container mt-5">
  <h1>Adicionar Equipamento</h1>
  <hr>
  <form action="{{route('equipamento.store')}}" method="POST">
    @csrf
    <div class="form-group">
      <div class="form-group">
        <label for="nome">Equipamento:</label>
        <input type="text" class="form-control" name="nome" placeholder="Insira o nome do equipamento">
      </div>
      <br>
      <div class="form-group">
        <label for="quantidade">Quantidade:</label>
        <input type="number" class="form-control" name="quantidade" placeholder="Insira a quantidade">
      </div>
      <br>
      <div class="form-group">
        <input type="submit" name="submit" class="btn btn-outline-primary">
      </div>
    </div>
  </form>
</div>




        

@endsection